jQuery( document ).ready( function( $ )
{
	$( '.ssfwc_social_share_buttons' ).css( 'visibility', 'visible' );
} );